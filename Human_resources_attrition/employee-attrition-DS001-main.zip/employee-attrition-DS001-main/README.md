# employee-attrition-DS001
Data Science Project: Employee Attrition Analysis using Python
